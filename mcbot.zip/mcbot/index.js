const mineflayer = require('mineflayer');

function createBot() {
  const bot = mineflayer.createBot({
    host: 'voltcraft.progamer.me',
    port: 20826,
    username: 'AFK_Bot_247'
  });

  bot.on('spawn', () => {
    console.log('البوت دخل السيرفر وبقى شغال!');
  });

  bot.on('end', () => {
    console.log('اتفصل، بيحاول يدخل تاني...');
    setTimeout(createBot, 5000);
  });

  bot.on('error', err => console.log(err));
}

createBot();
